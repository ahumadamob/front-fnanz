export const BASE_URL = '/app/dashboard/analytics';
export const BASE_TITLE = ' | Gradient Able Premium React + Admin Template';

export const CONFIG = {
  layout: 'vertical',
  layoutType: 'menu-light'
};
