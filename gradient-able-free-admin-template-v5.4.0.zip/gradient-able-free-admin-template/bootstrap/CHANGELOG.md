## [1.0.0] 2022-05-30

### Improvements

- Start Tracking version
